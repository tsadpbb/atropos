here you can find the configs that were used to create the baseline.
Make sure to adapt the paths to data and the experiments output!
